
import mysql.connector
import json
from decimal import Decimal
import pandas as pd

print('dependencias OK')

def conni():
    return  mysql.connector.connect(
    host="95.217.155.224",
    user="idesoftbcn",
    password="Idesoftbcn+03.",
    database="gestion_corner_mahou"  
)

def decimal_to_float(obj):

    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError(f'Object of type {obj.__class__.__name__} is not JSON serializable')

def fetch_data(query):

    connection = mysql.connector.connect(
    host="95.217.155.224",
    user="idesoftbcn",
    password="Idesoftbcn+03.",
    database="gestion_corner_mahou") 
       
    cursor = connection.cursor(dictionary=True)
    cursor.execute(query)
    results = cursor.fetchall()
    cursor.close()
    connection.close()
   
 
    results_json=json.dumps(results, default=decimal_to_float, indent=4)
    return results_json

def genprod(cati):
    categoria_deseada = cati
    if cati=='cervezas': 
        productos_filtrados = next(
        (
            [
                producto for producto in item['productos'] 
                if 'doble' not in producto.lower() and 
                'caña' not in producto.lower() and 
                'tercio' not in producto.lower()
            ]
            for item in infocarto if item['categoria'] == categoria_deseada
        ), 
        None
    )
    else:

   
        productos_filtrados = next((item['productos'] for item in infocarto if item['categoria'] == categoria_deseada), None)

    resultado = {'productos': productos_filtrados}
    return resultado


queryprodsid="SELECT productos.id, productos.nombre FROM productos JOIN sub_categorias ON productos.sub_categoria_id = sub_categorias.id JOIN categorias ON categorias.id = sub_categorias.categoria_id WHERE productos.deleted_at is null"
querycatsid="SELECT DISTINCT categorias.id, categorias.nombre FROM productos JOIN sub_categorias ON productos.sub_categoria_id = sub_categorias.id JOIN categorias ON categorias.id = sub_categorias.categoria_id WHERE productos.deleted_at is null"
querysubcatsid="SELECT DISTINCT sub_categorias.id, sub_categorias.nombre as subcat_nombre FROM productos JOIN sub_categorias ON productos.sub_categoria_id = sub_categorias.id JOIN categorias ON categorias.id = sub_categorias.categoria_id WHERE productos.deleted_at IS NULL"
queryprods = """
SELECT productos.id, productos.nombre, productos.descripcion, productos.precio, productos.experto, productos.info, productos.tiene_alcohol, sub_categorias.nombre as subcat_nombre, sub_categorias.descripcion as subcat_descripcion, sub_categorias.es_cerveza, categorias.nombre as cat_nombre, categorias.descripcion as cat_descripcion 
FROM productos 
JOIN sub_categorias ON productos.sub_categoria_id = sub_categorias.id 
JOIN categorias ON categorias.id = sub_categorias.categoria_id 
WHERE productos.deleted_at IS NULL;
"""


prodsid=json.loads(fetch_data(queryprodsid))
catsid=json.loads(fetch_data(querycatsid))
subcatsid=json.loads(fetch_data(querysubcatsid))

pathprod='https://plazamahou.es/products?productid='
productos_nv= {producto['nombre'].lower(): f"{pathprod}{producto['id']}" for producto in prodsid}
pathcat='https://plazamahou.es/products?cat='
cats_nv= {cat['nombre'].lower(): f"{pathcat}{cat['id']}" for cat in catsid}
pathsubcat='https://plazamahou.es/products?cat=4&subcat='
subcats_nv= {subcat['subcat_nombre'].lower(): f"{pathsubcat}{subcat['id']}" for subcat in subcatsid}
tourl={**productos_nv,**cats_nv,**subcats_nv}

queryprods = "SELECT productos.id, productos.nombre, productos.descripcion, productos.precio, productos.experto,productos.info,productos.tiene_alcohol,sub_categorias.nombre as subcat_nombre, sub_categorias.descripcion as subcat_descripcion, sub_categorias.es_cerveza,categorias.nombre as cat_nombre, categorias.descripcion as cat_descripcion FROM productos join sub_categorias ON productos.sub_categoria_id = sub_categorias.id join categorias on categorias.id = sub_categorias.categoria_id WHERE productos.deleted_at is null"

print('toURL OK')

conn = conni()
cursor = conn.cursor(dictionary=True)
cursor.execute(queryprods)

result = cursor.fetchall()
cursor.close()
conn.close()

df = pd.DataFrame(result)

productos_por_subcategoria = df.groupby('subcat_nombre')['nombre'].apply(list).reset_index()

infocarto = []
for _, row in productos_por_subcategoria.iterrows():
    infocarto.append({
        "categoria": row['subcat_nombre'],
        "productos": row['nombre']
    })

print('INFOcarto OK')

raciones=genprod('raciones')
aguas=genprod('aguas')
refrescos=genprod('refrescos')
vinos=genprod('vinos')
alcoholicas=genprod('alcoholicas')
raciones=genprod('raciones')
aperitivos=genprod('aperitivos')
entrepanes=genprod('entrepanes')
postres=genprod('postres')

print('Raciones,Aguas,Refrescos,Vinos,Alcoholicas,Aperitivos,Entrepanes,Postres OK')

conn = conni()

query_cervezas = """
SELECT 
    productos.nombre AS nombre,
    productos.descripcion AS descripcion,
    productos.precio AS precio,
    productos.tiene_alcohol AS tiene_alcohol,
    productos.experto AS experto
FROM 
    productos
JOIN 
    sub_categorias ON productos.sub_categoria_id = sub_categorias.id
JOIN 
    categorias ON categorias.id = sub_categorias.categoria_id
WHERE 
    productos.deleted_at IS NULL AND categorias.nombre = 'cervezas'
ORDER BY 
    productos.nombre;
"""


cursor = conn.cursor(dictionary=True)
cursor.execute(query_cervezas)
productos_cervezas = cursor.fetchall()
conn.close()


cervezas_list = []

for producto in productos_cervezas:


    if any(word in producto["nombre"].lower() for word in ["tercio", "doble", "caña"]):

        continue

    
    experto = ""
    if producto["experto"]:
        try:
            detalles = json.loads(producto["experto"])
            if isinstance(detalles, list) and len(detalles) > 0:
                experto_dict = detalles[0].get("es", {})
                alcohol = experto_dict.get("alcohol", "")
                curiosidadv = experto_dict.get("sabiasQue", "")
                amargorv = experto_dict.get("amargor", "")

        except json.JSONDecodeError:
            experto = ""

    cerveza_dict = {

        "nombre": producto["nombre"],
        "amargor":amargorv,
        "descripcion": producto["descripcion"],
        "precio": f'{producto["precio"]} €',
        "alcohol": f'{alcohol} grados',
        "curiosidad": curiosidadv,

    }

    cervezas_list.append(cerveza_dict)


cervezas= json.dumps(cervezas_list,default=decimal_to_float, indent=4, ensure_ascii=False)
print(f'Cervezas OK')

conn = conni()

cursor = conn.cursor(dictionary=True)


queryprods = """
SELECT 
    productos.id, 
    productos.nombre, 
    productos.descripcion, 
    productos.precio, 
    productos.experto,
    productos.info,
    productos.tiene_alcohol,
    sub_categorias.nombre as subcat_nombre, 
    sub_categorias.descripcion as subcat_descripcion, 
    sub_categorias.es_cerveza,
    categorias.nombre as cat_nombre, 
    categorias.descripcion as cat_descripcion
FROM 
    productos
JOIN 
    sub_categorias ON productos.sub_categoria_id = sub_categorias.id
JOIN 
    categorias ON categorias.id = sub_categorias.categoria_id
WHERE 
    productos.deleted_at IS NULL
    AND (categorias.nombre = 'Destacados' OR sub_categorias.nombre = 'Cervezas destacadas')
"""


cursor.execute(queryprods)


resultados = cursor.fetchall()


cursor.close()
conn.close()

recomendados=[]
for n in resultados:
    recomendados.append(n['nombre'])
print(f'Recomendados OK')

contenido = f"""
# Este archivo contiene datos obtenidos de una base de datos
tourl = {tourl}
infocarto={infocarto}
raciones={raciones}
aguas={aguas}
refrescos={refrescos}
vino={vinos}
alcoholicas={alcoholicas}
raciones={raciones}
aperitivos={aperitivos}
entrepanes={entrepanes}
postres={postres}
cervezas={cervezas}
recomendados={recomendados}
"""


with open("datos_guardados.py", "w",encoding='utf-8') as file:
    file.write(contenido)
    print(f'File datos_guardados OK')

