const express = require('express');
const bodyParser = require('body-parser');
const { spawn } = require('child_process');

const app = express();
const port = 3000;

app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

app.post('/process', (req, res) => {

    const userInput = req.body.input;
  
    const datos = {
        nombre: 'Raquel',
        idioma:'ES',
        userinput: userInput,
        contexto:[{'role':'user','content':userInput}], 
        noticias:''
      
      };
      console.log('ver_datos',datos)
    const pythonProcess = spawn('python', ['botmayo.py', JSON.stringify(datos)]);

    pythonProcess.stdout.on('data', (data) => {
        const response = data.toString();
        console.log('Respuesta del script de Python:', response);
        res.json({ response: response });

        const responseObject = JSON.parse(response);

        // Extraer la cadena contxt del objeto responseObject
        const contxtString = responseObject.contxt;        
        
        console.log('contxxxt', contxtString);
      
    });

    pythonProcess.stderr.on('data', (data) => {
        console.error('Error:', data.toString());
        res.status(500).json({ error: 'Internal Server Error' });
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
