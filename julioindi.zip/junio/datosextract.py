#%%
import mysql.connector
import json
from decimal import Decimal
import pandas as pd

#%%

def connx():
    conn = mysql.connector.connect(
    host="95.217.155.224",
    user="idesoftbcn",
    password="Idesoftbcn+03.",
    database="gestion_corner_mahou"  
)
    return conn


def decimal_to_float(obj):

    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError(f'Object of type {obj.__class__.__name__} is not JSON serializable')

def fetch_data(query):

    connection = mysql.connector.connect(
    host="95.217.155.224",
    user="idesoftbcn",
    password="Idesoftbcn+03.",
    database="gestion_corner_mahou") 
       
    cursor = connection.cursor(dictionary=True)
    cursor.execute(query)
    results = cursor.fetchall()
    cursor.close()
    connection.close()
   
    #results_json = json.dumps(results, indent=4)
    results_json=json.dumps(results, default=decimal_to_float, indent=4)
    return results_json

def genprod(cati):
    categoria_deseada = cati
    if cati=='cervezas': #para evitar cargar tipos de cerveza
        productos_filtrados = next(
        (
            [
                producto for producto in item['productos'] 
                if 'doble' not in producto.lower() and 
                'caña' not in producto.lower() and 
                'tercio' not in producto.lower()
            ]
            for item in estructura_deseada if item['categoria'] == categoria_deseada
        ), 
        None
    )
    else:



    # Filtrar el JSON para obtener los productos de la categoría deseada
        productos_filtrados = next((item['productos'] for item in estructura_deseada if item['categoria'] == categoria_deseada), None)

    # Crear la estructura deseada
    resultado = {'productos': productos_filtrados}
    return resultado
#%%
#1) Generación del TOURL

queryprodsid="SELECT productos.id, productos.nombre FROM productos JOIN sub_categorias ON productos.sub_categoria_id = sub_categorias.id JOIN categorias ON categorias.id = sub_categorias.categoria_id WHERE productos.deleted_at is null"
querycatsid="SELECT DISTINCT categorias.id, categorias.nombre FROM productos JOIN sub_categorias ON productos.sub_categoria_id = sub_categorias.id JOIN categorias ON categorias.id = sub_categorias.categoria_id WHERE productos.deleted_at is null"
querysubcatsid="SELECT DISTINCT sub_categorias.id, sub_categorias.nombre as subcat_nombre FROM productos JOIN sub_categorias ON productos.sub_categoria_id = sub_categorias.id JOIN categorias ON categorias.id = sub_categorias.categoria_id WHERE productos.deleted_at IS NULL"

prodsid=json.loads(fetch_data(queryprodsid))
catsid=json.loads(fetch_data(querycatsid))
subcatsid=json.loads(fetch_data(querysubcatsid))
#%%
pathprod='https://plazamahou.es/products?productid='
productos_nv= {producto['nombre'].lower(): f"{pathprod}{producto['id']}" for producto in prodsid}
pathcat='https://plazamahou.es/products?cat='
cats_nv= {cat['nombre'].lower(): f"{pathcat}{cat['id']}" for cat in catsid}
pathsubcat='https://plazamahou.es/products?cat=4&subcat='
subcats_nv= {subcat['subcat_nombre'].lower(): f"{pathsubcat}{subcat['id']}" for subcat in subcatsid}
tourl={**productos_nv,**cats_nv,**subcats_nv}
#%%
#2)INFOCARTO
queryprods = """
SELECT productos.id, productos.nombre, productos.descripcion, productos.precio, productos.experto, productos.info, productos.tiene_alcohol, sub_categorias.nombre as subcat_nombre, sub_categorias.descripcion as subcat_descripcion, sub_categorias.es_cerveza, categorias.nombre as cat_nombre, categorias.descripcion as cat_descripcion 
FROM productos 
JOIN sub_categorias ON productos.sub_categoria_id = sub_categorias.id 
JOIN categorias ON categorias.id = sub_categorias.categoria_id 
WHERE productos.deleted_at IS NULL;
"""
conn=connx()
# Crear un cursor para ejecutar la consulta
cursor = conn.cursor(dictionary=True)

# Ejecutar la consulta
cursor.execute(queryprods)

# Obtener todos los resultados
result = cursor.fetchall()

# Cerrar el cursor y la conexión
cursor.close()
conn.close()

# Convertir los resultados a un DataFrame de pandas
df = pd.DataFrame(result)

# Agrupar productos por subcategoría
productos_por_subcategoria = df.groupby('subcat_nombre')['nombre'].apply(list).reset_index()

# Convertir a la estructura deseada
infocarto = []
for _, row in productos_por_subcategoria.iterrows():
    infocarto.append({
        "categoria": row['subcat_nombre'],
        "productos": row['nombre']
    })

# Mostrar el resultado

# %%
#3)PRODUCTOS ESPECÍFICOS
raciones=genprod('raciones')
aguas=genprod('aguas')
refrescos=genprod('refrescos')
vinos=genprod('vinos')
alcoholicas=genprod('alcoholicas')
raciones=genprod('raciones')
aperitivos=genprod('aperitivos')
entrepanes=genprod('entrepanes')
postres=genprod('postres')
#%%
aperitivos
#%%
#4)CERVEZAS
conn = connx()

# Consulta para obtener los productos de la categoría "cervezas"
query_cervezas = """
SELECT 
    productos.nombre AS nombre,
    productos.descripcion AS descripcion,
    productos.precio AS precio,
    productos.tiene_alcohol AS tiene_alcohol,
    productos.experto AS experto
FROM 
    productos
JOIN 
    sub_categorias ON productos.sub_categoria_id = sub_categorias.id
JOIN 
    categorias ON categorias.id = sub_categorias.categoria_id
WHERE 
    productos.deleted_at IS NULL AND categorias.nombre = 'cervezas'
ORDER BY 
    productos.nombre;
"""

# Ejecutar la consulta
cursor = conn.cursor(dictionary=True)
cursor.execute(query_cervezas)
productos_cervezas = cursor.fetchall()
conn.close()

# Procesar los datos para formar el diccionario deseado
cervezas_list = []

for producto in productos_cervezas:
    # Filtrar productos que contengan "tercio", "doble" o "caña" en el nombre

    if any(word in producto["nombre"].lower() for word in ["tercio", "doble", "caña"]):

        continue

    # Parsear experto JSON si está presente y verificar si es una lista
    experto = ""
    if producto["experto"]:
        try:
            detalles = json.loads(producto["experto"])
            if isinstance(detalles, list) and len(detalles) > 0:
                experto_dict = detalles[0].get("es", {})
                alcohol = experto_dict.get("alcohol", "")
                curiosidadv = experto_dict.get("sabiasQue", "")
                amargorv = experto_dict.get("amargor", "")

        except json.JSONDecodeError:
            experto = ""

    cerveza_dict = {

        "nombre": producto["nombre"],
        "amargor":amargorv,
        "descripcion": producto["descripcion"],
        "precio": f'{producto["precio"]} €',
        "alcohol": f'{alcohol} grados',
        "curiosidad": curiosidadv,

    }

    cervezas_list.append(cerveza_dict)

# Convertir la lista de diccionarios a formato JSON para visualización
cervezas= json.dumps(cervezas_list,default=decimal_to_float, indent=4, ensure_ascii=False)

# %%
#4)PRODUCTOS DESTACADOS

conn = connx()

cursor = conn.cursor(dictionary=True)

# Consulta SQL para obtener productos destacados
queryprods = """
SELECT 
    productos.id, 
    productos.nombre, 
    productos.descripcion, 
    productos.precio, 
    productos.experto,
    productos.info,
    productos.tiene_alcohol,
    sub_categorias.nombre as subcat_nombre, 
    sub_categorias.descripcion as subcat_descripcion, 
    sub_categorias.es_cerveza,
    categorias.nombre as cat_nombre, 
    categorias.descripcion as cat_descripcion
FROM 
    productos
JOIN 
    sub_categorias ON productos.sub_categoria_id = sub_categorias.id
JOIN 
    categorias ON categorias.id = sub_categorias.categoria_id
WHERE 
    productos.deleted_at IS NULL
    AND (categorias.nombre = 'Destacados' OR sub_categorias.nombre = 'Cervezas destacadas')
"""

# Ejecutar la consulta
cursor.execute(queryprods)

# Obtener los resultados
resultados = cursor.fetchall()

# Cerrar el cursor y la conexión
cursor.close()
conn.close()
recomendados=[]
for n in resultados:
    recomendados.append(n['nombre'])
