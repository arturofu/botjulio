
import sys
#from datosaux import*
from datos_guardados import*
import json
from openai import OpenAI
import re
import os
import ast
from dotenv import find_dotenv, load_dotenv
import openai


load_dotenv(find_dotenv())

openai.api_key=os.getenv('OPENAI_API_KEY')
client = OpenAI()

#GPT_MODEL = 'gpt-3.5-turbo'
GPT_MODEL = 'gpt-4o'
#FUNCIONES

#Extrae elementos de entrada de la funcion

def getelementos(respuesta):
    
    resultado = re.search(r'/([^/]+)/', respuesta)
    resclean=re.sub(r'/[^/]+/', '', respuesta)
   
    if resultado:
        contenido_intermedio = resultado.group(1)    
        #Divide el contenido extraído en elementos separados por comas
        elementos = contenido_intermedio.split(',')
  
    return elementos,resclean
def detectar_elemento_vacio(elemento):
    try:
        # Convierte el elemento a una estructura de datos real de Python
        elemento_evaluado = ast.literal_eval(elemento)
        # Comprueba si el elemento evaluado es una lista y si está vacía o contiene solo elementos vacíos
        if isinstance(elemento_evaluado, list) and not any(elemento_evaluado):
            return True
        else:
            return False
    except (ValueError, SyntaxError):
        # Si hay un error al evaluar, asume que el elemento no es una estructura de lista o es un formato inválido
        return False
def sanit(elementos):

    conturl=[]

    for n in elementos:
        if detectar_elemento_vacio(n):
      
            conturl.append('noinfo')
        else:
      
            n = n.replace('[', '',).replace(']', '').replace("'", "")       
      
            conturl.append(n)
    return conturl

def producto_en_categoria(catin,prodin):
    deliv=''
  
    for cat in infocarto:       

        if cat["categoria"].lower() == catin.lower():
           
            deliv=catin.lower()

            for pr in cat["productos"]:             
              
                if pr.lower()==prodin.lower():
        
                    deliv=pr.lower()
        
    return deliv

def geturl(assis,tourl):
    
    conturl=[]
 
    elementos,resclean=getelementos(assis)
 
    conturl=sanit(elementos)
   
    forurl=producto_en_categoria(conturl[0],conturl[1])

    url2='no'

    if forurl in tourl:
        
        url2=tourl[forurl]

    else:

        url2='no'
    
    return url2,resclean


respondtot=0
tools = [
{
  "type": "function",
  "function": {
    "name": "speak_to_user",
    "description": "Use this to speak to the user to give them information and to ask for anything required for their case.",
    "parameters": {
      "type": "object",
      "properties": {
        "message": {
          "type": "string",
          "description": "Text of message to send to user. Can cover multiple topics."
        },"product_pet": {
          "type": "array",          
          "items":{
              "type":"string"
          },
          "description": """nombre de producto sobre el que pregunta el cliente"""
        },
        "product_catg": {
          "type": "string",
           
         "enum": ["cervezas,refrescos,vinos,alcoholicas,aguas,raciones,entrepanes,postres,None"],
          "description": """categoria sobre la que se ubica el producto pedido por el usuario:
          -cervezas: productos de la marca Mahou
          -refrescos: refrescos sin alcohol
          -vinos: vinos
          -alcoholicas: otras bebidas alcoholicas que NO son cervezas o vinos
          -aguas: aguas
          -raciones: porción grande de comida
          -aperitivos: porción pequeña de comida
          -entrepanes: tipos de bocadillo
          -postres: platos dulces
        
         
          -None: no es ningun producto enmarcable en bebidas o comidas"""
        },
      },
      "required": ["message","product_pet","product_catg"]
    }
  }
},
{
  "type": "function",
  "function": {
    "name": "get_instructions",
    "description": "Used to get instructions to deal with the user's request.",
    "parameters": {
      "type": "object",
      "properties": {
        "problem": {
          "type": "string",
          "enum": ["carta","informacion","refuse"],
          "description": """The type of problem the customer has. Can be one of:
          - carta: instrucciones para pedir un producto de la carta
          - informacion: informacion genérica del espacio y de la biografia de Manuel         
          - refuse: para opiniones comprometidas sobre Mahou o San Miguel o de la competencia """
        },
         "product_pet": {
          "type": "array",          
          "items":{
              "type":"string"
          },
          "description": """nombre de producto sobre el que pregunta el cliente"""
        },
        "product_catg": {
          "type": "string",
           
         "enum": ["cervezas,refrescos,vinos,alcoholicas,aguas,raciones,entrepanes,postres,None"],
          "description": """categoria sobre la que se ubica el producto pedido por el usuario:
          -cervezas: productos de la marca Mahou
          -refrescos: refrescos sin alcohol
          -vinos: vinos
          -alcoholicas: otras bebidas alcoholicas que NO son cervezas o vinos
          -aguas: aguas
          -raciones: porción grande de comida
          -aperitivos: porción pequeña de comida
          -entrepanes: tipos de bocadillo
          -postres: platos dulces
         
         
          -None: no es ningun producto enmarcable en bebidas o comidas"""
        },
        
      },
      "required": [
        "problem","product_pet","product_catg"
      ]
    }
  }
},
]

class Chatbot:

    def __init__(self,nombre,idioma,contexto,tiempo):
        self.openai_api_key = os.getenv("OPENAI_API_KEY")
        self.nombre=nombre
        self.langs={'EN':'english','ES':"español"}
        self.tiempo=tiempo
        self.noticias="el Madrid ganó la 15 Champions"
        self.lang=self.langs[idioma]        
        self.product_pet='nada'
        self.product_cat='nada'
        self.assistantm=''
        self.error=False
        self.typerr='ninguno'
        self.conversation_messages=[]
        
        self.contexto=contexto
        self.standard=f"""You are a professional waiter named Manuel, working for the Mahou brand. 
        .Conversation language: {self.lang}                  
        Your knowledge of the bar menu: {infocarto}. All products are available and you advise to have a drink or grab something to eat/drink (para picar o tomar algo).
        You can recommend but not add to the cart, and you cannot confirm any order, nor bring any product to the table. If the user wants to order something, they need to select it from the app.
        Your role is to answer user questions politely and competently, and you can address the customer by their name {self.nombre}.
        Do not invent products not previously consulted in the menu.
        Tercio,doble y caña are ways to serve beer.
        Pulguita and bocata are entrepanes sizes.
        You like to use football metaphors when you speak, as well as refer to the weather in Madrid (for that, you will have the temperature in degrees: {self.tiempo} but refer to that in general terms), and the latest news about Real Madrid :{self.noticias}.
        If they want to add any clarification about a product, you must indicate they do so through the app checkout.

        Respond with a maximum of 20 words."""

        self.instructionsop= [ {"type": "carta",
                  "instructions": f"""
                  .Conversation language: {self.lang},
• Ask the customer what type of product they are interested in and respond based on your knowledge of the productos of the menu.              
- You must gauge their mood and make them feel heard.
- If they are unsure about what to consume, keep asking questions to help them decide.
- If they want to order something, remind them to do so through the app menu.
- If they want to split the bill, they should notify a waiter in the room.

                 """},

                {"type": "informacion",                 
                 "instructions": f"""
                 Conversation language: {self.lang},
                 • Provide information (in the language the customer uses) related to the brand, details about the space, and the waiter's biography.
- You must give precise information and cannot make up anything you do not know.
""" },
                {"type": "refuse",
                 "instructions": f"""
                 Conversation language: {self.lang},
                 - For opinions on products that are not Mahou or San Miguel:
  - Respond politely (in the language the customer uses) that you cannot fulfill their request.
- Provide accurate and clear information based on the customer's questions.
- Offer to assist with any additional questions or provide further details if needed.

                """ }]

    def initchat(self):

        assistant_system_prompt=self.standard
        
        self.conversation_messages.append({
                "role": "system",
                "content": assistant_system_prompt                
            })
        
        for x in self.contexto:
            self.conversation_messages.append(x)  
        
        if self.lang=='español':
            self.adv1="¿Puedes ser más específico por favor?./[0,0]/"
            self.adv2="Disculpa, ahora mismo no estoy disponible, vuelvo en un minuto"
        else:
            self.adv1="Could you be more specific, please?./[0,0]/"
            self.adv2="Sorry, I'm not available right now. I'll be back in a minute"

    def contextload(self,contx):

        if contx=='standard':
            assistant_system_prompt = self.standard            
        
        elif contx=='cervezas':
            assistant_system_prompt = f"""You are a professional waiter named Manuel.
Conversation language: {self.lang}     
You must follow these instructions:
- Understand the customer's request and extract relevant instructions.
- if user wants more detailed information, he should check the beer's datasheet.
- You rely on the knowledge of beer information: {cervezas}. All products are available.
-If the user doesn't know what to drink or is thirsty, you can recommend one of them.
- Always recommend consulting the menu for other options.
- You can only recommend beers you know. If asked for a recommendation, you can offer Mahou Clásica.
- Restrictions: they cannot order in any format other than double keg, caña, or tercio bottle.
- Respond with a maximum of 20 words."""
        
        elif contx=='vinos':
            assistant_system_prompt = f"""You are a professional waiter named Manuel.
            
You rely on the wine information: {vinos}. All products are available.
You can only recommend wines you know.
Respond with a maximum of 20 words."""        
        
        elif contx=='refrescos':
            assistant_system_prompt = f"""You are a professional waiter named Manuel.
            
You rely on the soda information: {refrescos}. All products are available.
You cannot invent sodas you don't know.
Respond with a maximum of 20 words."""        
        
        elif contx=='raciones':
            assistant_system_prompt = f"""You are a professional waiter named Manuel.
        
You rely on the information of raciones: {raciones}. All products are available.
If the user doesn't know what to eat or is hungry, you can recommend one of them.
You cannot invent raciones you don't know.
If the user wants to place an order, indicate they do so through the app menu.
If they want a product served a certain way, indicate they specify it through the app checkout.
Respond with a maximum of 20 words.. 
            """

        elif contx=='aperitivos':
            assistant_system_prompt = f"""You are a professional waiter named Manuel.
        
You rely on the information of aperitivos: {aperitivos}. All products are available.
If the user doesn't know what to eat or is hungry, you can recommend one of them.
You cannot invent aperitivos you don't know.
If the user wants to place an order, indicate they do so through the app menu.
If they want a product served a certain way, indicate they specify it through the app checkout.
Respond with a maximum of 20 words. 
            """
        
        elif contx=='aguas':
            assistant_system_prompt = f"""You are a professional waiter named Manuel.

You rely on the information of waters: {aguas}. All products are available.
You cannot invent waters not included.
Respond with a maximum of 20 words.. 
            """
        
        elif contx=='entrepanes':
            assistant_system_prompt = f"""You are a professional waiter named Manuel.
   
You rely on the information of sandwiches: {entrepanes}. All products are available.
You cannot invent sandwiches you don't know.
Respond with a maximum of 20 words. 

            """       

        elif contx=='postres':
            assistant_system_prompt = f"""You are a professional waiter named Manuel.
         
You rely on the information of desserts: {postres}. All products are available.
You cannot invent desserts you don't know.
Respond with a maximum of 20 words.
            """     

        elif contx=='alcoholicas':
            assistant_system_prompt = f"""You are a professional waiter named Manuel.       
You rely on the information of other alcoholic drinks: {alcoholicas}. All products are available.
You cannot invent drinks you don't know.
Respond with a maximum of 20 words. 
            """            
       
        else:

            assistant_system_prompt =f"""You are a professional waiter named Manuel. 
            Conversation language: {self.lang},
            Your knowledge of the bar menu: {infocarto}. All products are available.
            If they is hungry or thirsty, recommend: {recomendados}.
            Information about activities within the Mahou space at the Santiago Bernabéu (where we are located):: 'tira la caña', 'visita a la micro'...
If asked about you, mention you were born in Madrid and you are a Real Madrid fan.
If asked about the kitchen: it is not prepared to avoid cross-contamination for celiacs.
If interested in an activity, indicate they should check the agenda in the top menu.
Do not invent products or activities not previously consulted in the menu.
If they ask about promotions, direct them to the personal area of the app.
Your role is to answer user questions politely and competently.
You should follow these instructions to solve the case:
Follow the instructions to solve the customer's petition.
Respond with a maximum of 20 words.
Only call a tool once in a single message."""          
               
        return assistant_system_prompt

    def submit_user_message(self,user_query):
        
        respond = False
   
        respondtot=0
        context='standard' 

        while respond is False:
        
            respondtot=respondtot+1

            if respondtot>3:
               
                respond=True
            
                self.assistantm=self.adv1
            
            else:               
                
                assistant_system_prompt=self.contextload(context)
                messages = [
                    {
                        "role": "system",
                        "content": assistant_system_prompt
                    }
                ]
                
                [messages.append(x) for x in self.conversation_messages]                
                 
                try:
               
                    response = client.chat.completions.create(model=GPT_MODEL
                                                            ,messages=messages
                                                            ,temperature=0.2
                                                            ,tools=tools
                                                            ,tool_choice='required'
                                                            )
                    
                    self.error=False

                except openai.APIError as e:
                    self.error=True
                    self.typerr=e
                    response=''
                    context=''
                    respond=True
                    self.assistantm=self.adv2
                  
            
                except openai.APIConnectionError as e:
                    self.error=True
                    self.typerr=e
                    response=''
                    context=''
                    respond=True
                    self.assistantm=self.adv2
                
                         
            
                except openai.RateLimitError as e:
                    self.error=True
                    self.typerr=e
                    response=''
                    context=''
                    respond=True
                    self.assistantm=self.adv2
               
                
                if self.error==False:
                    self.conversation_messages.append(response.choices[0].message)                 
            
                    context,respond,self.conversation_messages= self.execute_function(response.choices[0].message,self.conversation_messages)
             

        return self.assistantm

    def execute_function(self,function_calls,messages):
        
        product_pet=None

        for function_call in function_calls.tool_calls:

            function_arguments = json.loads(function_call.function.arguments)
            function_id = function_call.id
            function_name = function_call.function.name        
                  
                
            if function_name == 'get_instructions':

                respond = False          
                instruction_name = function_arguments['problem']
                product_pet=function_arguments['product_pet']
                product_catg=function_arguments['product_catg']
            
                self.product_pet= product_pet
                self.product_cat=product_catg
       
                if len(self.product_pet)>2:
                    self.product_pet=[]
                context=product_catg         
                
                instructions = self.instructionsop['type' == instruction_name]
                                        
                messages.append(
                                    {
                                        "tool_call_id": function_id,
                                        "role": "tool",
                                        "name": function_name,
                                        "content": instructions['instructions'],                                                                  
                                        
                                    }
                                )
                           
            elif function_name != 'get_instructions':

                respond = True 
                context=None
                product_pet=function_arguments['product_pet']
                product_catg=function_arguments['product_catg']
            
                self.product_pet= product_pet
                
                if len(self.product_pet)>2:
                    self.product_pet=[]
                self.product_cat=product_catg                        
                contf=str(function_arguments['message']+'/'+str(self.product_cat)+','+str(self.product_pet)+'/')
                messages.append(
                                    {
                                        "tool_call_id": function_id,
                                        "role": "tool",
                                        "name": function_name,
                                        "content": function_arguments['message'],
                                    }
                                )
                        
       
                self.assistantm=contf
        
        return (context,respond, messages)      


def main():   
 
    #deserealizar el json
    argsString = sys.argv[1]
    args = json.loads(argsString)
    #extraer campos del json 
    nombre= args["nombre"]
    idioma=args['idioma']   
    contexto = args["contexto"]    
    userinput=args["userinput"] 
    tiempo=args["tiempo"] #pendiente
    noticias=args["noticias"] #pendiente
   
    chatbot = Chatbot(nombre,idioma,contexto,tiempo) #inicializacion objeto chatbot con el nombre usuario y contexto
   
    chatbot.initchat()
    resasis=chatbot.submit_user_message(userinput)  
   
    if chatbot.error==False:  
        url,resclean=geturl(resasis,tourl)

    else:
        resclean=''
        url=''
   
    salida={

        "error":f"{str(chatbot.error)}", 
        "tipo de error":f"{chatbot.typerr}",
        "respuesta":f"{resclean}",
        "link":f"{url}",
        
    }
    sys.stdout.write(json.dumps(salida) + '\n')
    sys.stdout.flush()


if __name__ == "__main__":
    main()
    