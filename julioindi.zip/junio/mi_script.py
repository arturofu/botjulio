
def saludar(nombre):
    return f"Hola, {recomendados}!"

if __name__ == "__main__":
    nombre = input("Introduce tu nombre: ")
    print(saludar(nombre))
