#%%
#criterio de armar documento // 
#armar categorias 

import mysql.connector
import json
from decimal import Decimal

def decimal_to_float(obj):

    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError(f'Object of type {obj.__class__.__name__} is not JSON serializable')

def fetch_data(query):

    connection = mysql.connector.connect(
    host="95.217.155.224",
    user="idesoftbcn",
    password="Idesoftbcn+03.",
    database="gestion_corner_mahou") 
       
    cursor = connection.cursor(dictionary=True)
    cursor.execute(query)
    results = cursor.fetchall()
    cursor.close()
    connection.close()
   
    #results_json = json.dumps(results, indent=4)
    results_json=json.dumps(results, default=decimal_to_float, indent=4)
    return results_json

#%%

queryprodsid="SELECT productos.id, productos.nombre FROM productos JOIN sub_categorias ON productos.sub_categoria_id = sub_categorias.id JOIN categorias ON categorias.id = sub_categorias.categoria_id WHERE productos.deleted_at is null"
querycatsid="SELECT DISTINCT categorias.id, categorias.nombre FROM productos JOIN sub_categorias ON productos.sub_categoria_id = sub_categorias.id JOIN categorias ON categorias.id = sub_categorias.categoria_id WHERE productos.deleted_at is null"
querysubcatsid="SELECT DISTINCT sub_categorias.id, sub_categorias.nombre as subcat_nombre FROM productos JOIN sub_categorias ON productos.sub_categoria_id = sub_categorias.id JOIN categorias ON categorias.id = sub_categorias.categoria_id WHERE productos.deleted_at IS NULL"

prodsid=json.loads(fetch_data(queryprodsid))
catsid=json.loads(fetch_data(querycatsid))
subcatsid=json.loads(fetch_data(querysubcatsid))
#%%

print('categorias',catsid)
print('subcategorias',subcatsid)

#%%

#%%
#ARMAR EL LISTADO DE LINKS

pathprod='https://plazamahou.es/products?productid='
productos_nv= {producto['nombre'].lower(): f"{pathprod}{producto['id']}" for producto in prodsid}
pathcat='https://plazamahou.es/products?cat='
cats_nv= {cat['nombre'].lower(): f"{pathcat}{cat['id']}" for cat in catsid}
pathsubcat='https://plazamahou.es/products?cat=4&subcat='
subcats_nv= {subcat['subcat_nombre'].lower(): f"{pathsubcat}{subcat['id']}" for subcat in subcatsid}
tourl={**productos_nv,**cats_nv,**subcats_nv}
#%%
tourl
#%%
# Procesar los datos para formar la estructura deseada
estructura_deseada = []

# Crear un diccionario para mapear categorías y subcategorías a sus productos
categorias_dict = {}

for prod_id, prod_nombre, subcat_nombre, cat_nombre in prodsid:
    if cat_nombre not in categorias_dict:
        categorias_dict[cat_nombre] = {}
    if subcat_nombre not in categorias_dict[cat_nombre]:
        categorias_dict[cat_nombre][subcat_nombre] = []
    categorias_dict[cat_nombre][subcat_nombre].append(prod_nombre)

# Crear la estructura final
for cat_nombre, subcats in categorias_dict.items():
    productos_list = [prod for subcat in subcats.values() for prod in subcat
                      if 'doble' not in prod.lower() and 'caña' not in prod.lower() and 'tercio' not in prod.lower()]
    estructura_deseada.append({
        "categoria": cat_nombre,
        "productos": productos_list
    })

import json

# Convertir la estructura a formato JSON
estructura_json = json.dumps(estructura_deseada, indent=4, ensure_ascii=False)
print(estructura_json)

#%%
#Generación de productos

queryprods = "SELECT productos.id, productos.nombre, productos.descripcion, productos.precio, productos.experto,productos.info,productos.tiene_alcohol,sub_categorias.nombre as subcat_nombre, sub_categorias.descripcion as subcat_descripcion, sub_categorias.es_cerveza,categorias.nombre as cat_nombre, categorias.descripcion as cat_descripcion FROM productos join sub_categorias ON productos.sub_categoria_id = sub_categorias.id join categorias on categorias.id = sub_categorias.categoria_id WHERE productos.deleted_at is null"
#%%
#INFOCARTO

import mysql.connector
import pandas as pd
conn = mysql.connector.connect(
     host="95.217.155.224",
    user="idesoftbcn",
    password="Idesoftbcn+03.",
    database="gestion_corner_mahou"  
)

# Definir la consulta SQL
queryprods = """
SELECT productos.id, productos.nombre, productos.descripcion, productos.precio, productos.experto, productos.info, productos.tiene_alcohol, sub_categorias.nombre as subcat_nombre, sub_categorias.descripcion as subcat_descripcion, sub_categorias.es_cerveza, categorias.nombre as cat_nombre, categorias.descripcion as cat_descripcion 
FROM productos 
JOIN sub_categorias ON productos.sub_categoria_id = sub_categorias.id 
JOIN categorias ON categorias.id = sub_categorias.categoria_id 
WHERE productos.deleted_at IS NULL;
"""

# Crear un cursor para ejecutar la consulta
cursor = conn.cursor(dictionary=True)

# Ejecutar la consulta
cursor.execute(queryprods)

# Obtener todos los resultados
result = cursor.fetchall()

# Cerrar el cursor y la conexión
cursor.close()
conn.close()

# Convertir los resultados a un DataFrame de pandas
df = pd.DataFrame(result)

# Agrupar productos por subcategoría
productos_por_subcategoria = df.groupby('subcat_nombre')['nombre'].apply(list).reset_index()

# Convertir a la estructura deseada
estructura_deseada = []
for _, row in productos_por_subcategoria.iterrows():
    estructura_deseada.append({
        "categoria": row['subcat_nombre'],
        "productos": row['nombre']
    })

# Mostrar el resultado
print(estructura_deseada)

# %%
estructura_deseada
# %%

categoria_deseada = 'aguas'

# Filtrar el JSON para obtener los productos de la categoría deseada
productos_filtrados = next((item['productos'] for item in estructura_deseada if item['categoria'] == categoria_deseada), None)

# Crear la estructura deseada
resultado = {'productos': productos_filtrados}

# Mostrar el resultado
print(resultado)
# %%
def genprod(cati):
    categoria_deseada = cati
    if cati=='cervezas': #para evitar cargar tipos de cerveza
        productos_filtrados = next(
        (
            [
                producto for producto in item['productos'] 
                if 'doble' not in producto.lower() and 
                'caña' not in producto.lower() and 
                'tercio' not in producto.lower()
            ]
            for item in estructura_deseada if item['categoria'] == categoria_deseada
        ), 
        None
    )
    else:



    # Filtrar el JSON para obtener los productos de la categoría deseada
        productos_filtrados = next((item['productos'] for item in estructura_deseada if item['categoria'] == categoria_deseada), None)

    # Crear la estructura deseada
    resultado = {'productos': productos_filtrados}
    return resultado

genprod('raciones')

# %%

raciones=genprod('raciones')
raciones
#%%
raciones=genprod('raciones')
aguas=genprod('aguas')
refrescos=genprod('refrescos')
vino=genprod('vino')
alcoholicas=genprod('alcoholicas')
raciones=genprod('raciones')
aperitivos=genprod('Aperitivos')
entrepanes=genprod('Entrepanes')
Postres=genprod('Postres')
cervezas=genprod('cervezas')

#%%

#da información estructurada de subcategorías y productos. 

# Suponiendo que ya tienes una conexión a la base de datos

conn = mysql.connector.connect(
     host="95.217.155.224",
    user="idesoftbcn",
    password="Idesoftbcn+03.",
    database="gestion_corner_mahou"  
)

query = """
SELECT 
    categorias.nombre AS categoria,
    sub_categorias.nombre AS subcategoria,
    productos.nombre AS producto
FROM 
    productos
JOIN 
    sub_categorias ON productos.sub_categoria_id = sub_categorias.id
JOIN 
    categorias ON categorias.id = sub_categorias.categoria_id
WHERE 
    productos.deleted_at IS NULL
ORDER BY 
    categorias.nombre, sub_categorias.nombre, productos.nombre;
"""

# Ejecutar la consulta
cursor = conn.cursor()
cursor.execute(query)
resultados = cursor.fetchall()
conn.close()

# Procesar los datos para formar la estructura deseada
estructura_deseada = []
categorias_dict = {}

for categoria, subcategoria, producto in resultados:
    if categoria not in categorias_dict:
        categorias_dict[categoria] = {}
    if subcategoria not in categorias_dict[categoria]:
        categorias_dict[categoria][subcategoria] = []
    categorias_dict[categoria][subcategoria].append(producto)

# Crear la estructura final
for cat_nombre, subcats in categorias_dict.items():
    subcats_list = []
    for subcat_nombre, productos in subcats.items():
        productos_list = [prod for prod in productos
                          if 'doble' not in prod.lower() and 'caña' not in prod.lower() and 'tercio' not in prod.lower()]
        subcats_list.append({
            "subcategoria": subcat_nombre,
            "productos": productos_list
        })
    estructura_deseada.append({
        "categoria": cat_nombre,
        "subcategorias": subcats_list
    })

#%%
# Convertir la estructura a formato JSON
estructura_json = json.dumps(estructura_deseada, indent=4, ensure_ascii=False)
print(estructura_json)

# %%

# Procesar los datos para formar la estructura deseada de la categoría "cervezas"
categoria_deseada = "cervezas"
estructura_cervezas = []
cervezas_dict = {}

for categoria, subcategoria, producto in resultados:
    if categoria.lower() == categoria_deseada:
        if subcategoria not in cervezas_dict:
            cervezas_dict[subcategoria] = []
        cervezas_dict[subcategoria].append(producto)

# Crear la estructura final para "cervezas"
for subcat_nombre, productos in cervezas_dict.items():
    productos_list = [prod for prod in productos
                      if 'doble' not in prod.lower() and 'caña' not in prod.lower() and 'tercio' not in prod.lower()]
    estructura_cervezas.append({
        "subcategoria": subcat_nombre,
        "productos": productos_list
    })

# Convertir la estructura a formato JSON
estructura_json = json.dumps({
    "categoria": categoria_deseada,
    "subcategorias": estructura_cervezas
}, indent=4, ensure_ascii=False)

print(estructura_json)

# %%
conn = mysql.connector.connect(
     host="95.217.155.224",
    user="idesoftbcn",
    password="Idesoftbcn+03.",
    database="gestion_corner_mahou"  
)
# Consulta para obtener los campos de la tabla productos


# Consulta para obtener los campos de la tabla productos
query_schema = "SHOW COLUMNS FROM productos;"

# Ejecutar la consulta
cursor = conn.cursor()
cursor.execute(query_schema)
columnas = cursor.fetchall()

# Mostrar las columnas disponibles
print("Campos disponibles en la tabla 'productos':")
for columna in columnas:
    print(f"{columna[0]} (tipo: {columna[1]})")

# Consulta para obtener los productos de la categoría "cervezas"
query_cervezas = """
SELECT 
    categorias.nombre AS categoria,
    sub_categorias.nombre AS subcategoria,
    productos.*
FROM 
    productos
JOIN 
    sub_categorias ON productos.sub_categoria_id = sub_categorias.id
JOIN 
    categorias ON categorias.id = sub_categorias.categoria_id
WHERE 
    productos.deleted_at IS NULL AND categorias.nombre = 'cervezas'
ORDER BY 
    categorias.nombre, sub_categorias.nombre, productos.nombre;
"""

# Ejecutar la consulta
cursor.execute(query_cervezas)
productos_cervezas = cursor.fetchall()

# Mostrar los productos de la categoría 'cervezas'
print("\nProductos en la categoría 'cervezas':")
for producto in productos_cervezas:
    print(producto)

conn.close()

# %%

# Conectar a la base de datos MySQL
conn = mysql.connector.connect(
     host="95.217.155.224",
    user="idesoftbcn",
    password="Idesoftbcn+03.",
    database="gestion_corner_mahou"  
)

# Consulta para obtener los productos de la categoría "cervezas"
query_cervezas = """
SELECT 
    productos.nombre AS nombre,
    productos.descripcion AS descripcion,
    productos.precio AS precio,
    productos.tiene_alcohol AS tiene_alcohol,
    productos.experto AS experto
FROM 
    productos
JOIN 
    sub_categorias ON productos.sub_categoria_id = sub_categorias.id
JOIN 
    categorias ON categorias.id = sub_categorias.categoria_id
WHERE 
    productos.deleted_at IS NULL AND categorias.nombre = 'cervezas'
ORDER BY 
    productos.nombre;
"""

# Ejecutar la consulta
cursor = conn.cursor(dictionary=True)
cursor.execute(query_cervezas)
productos_cervezas = cursor.fetchall()
conn.close()

# Procesar los datos para formar el diccionario deseado
cervezas_list = []

for producto in productos_cervezas:
    # Filtrar productos que contengan "tercio", "doble" o "caña" en el nombre
    if any(word in producto["nombre"].lower() for word in ["tercio", "doble", "caña"]):
        continue

    # Parsear experto JSON si está presente y verificar si es un diccionario
    experto = ""
    if producto["experto"]:
        try:
            detalles = json.loads(producto["experto"])
            if isinstance(detalles, dict):
                experto = detalles.get("es", {}).get("alcohol", "")
        except json.JSONDecodeError:
            experto = ""

    cerveza_dict = {
        "nombre": producto["nombre"],
        "descripcion": producto["descripcion"],
        "precio": producto["precio"],
        "tiene_alcohol": producto["tiene_alcohol"],
        "experto": producto['experto']
    }
    cervezas_list.append(cerveza_dict)

# Convertir la lista de diccionarios a formato JSON para visualización
estructura_json = json.dumps(cervezas_list,default=decimal_to_float, indent=4, ensure_ascii=False)
print(estructura_json)


# %%
# EXTRACCION DE CERVEZAS

conn = mysql.connector.connect(
     host="95.217.155.224",
    user="idesoftbcn",
    password="Idesoftbcn+03.",
    database="gestion_corner_mahou"  
)

# Consulta para obtener los productos de la categoría "cervezas"
query_cervezas = """
SELECT 
    productos.nombre AS nombre,
    productos.descripcion AS descripcion,
    productos.precio AS precio,
    productos.tiene_alcohol AS tiene_alcohol,
    productos.experto AS experto
FROM 
    productos
JOIN 
    sub_categorias ON productos.sub_categoria_id = sub_categorias.id
JOIN 
    categorias ON categorias.id = sub_categorias.categoria_id
WHERE 
    productos.deleted_at IS NULL AND categorias.nombre = 'cervezas'
ORDER BY 
    productos.nombre;
"""

# Ejecutar la consulta
cursor = conn.cursor(dictionary=True)
cursor.execute(query_cervezas)
productos_cervezas = cursor.fetchall()
conn.close()

# Procesar los datos para formar el diccionario deseado
cervezas_list = []

for producto in productos_cervezas:
    # Filtrar productos que contengan "tercio", "doble" o "caña" en el nombre

    if any(word in producto["nombre"].lower() for word in ["tercio", "doble", "caña"]):

        continue

    # Parsear experto JSON si está presente y verificar si es una lista
    experto = ""
    if producto["experto"]:
        try:
            detalles = json.loads(producto["experto"])
            if isinstance(detalles, list) and len(detalles) > 0:
                experto_dict = detalles[0].get("es", {})
                alcohol = experto_dict.get("alcohol", "")
                curiosidadv = experto_dict.get("sabiasQue", "")
                amargorv = experto_dict.get("amargor", "")

        except json.JSONDecodeError:
            experto = ""

    cerveza_dict = {

        "nombre": producto["nombre"],
        "amargor":amargorv,
        "descripcion": producto["descripcion"],
        "precio": f'{producto["precio"]} €',
        "alcohol": f'{alcohol} grados',
        "curiosidad": curiosidadv,

    }

    cervezas_list.append(cerveza_dict)

# Convertir la lista de diccionarios a formato JSON para visualización
cervezas_des = json.dumps(cervezas_list,default=decimal_to_float, indent=4, ensure_ascii=False)
print(cervezas_des)

# %%
cervezas_des
# %%
##EXTRACCIÓN DE PRODUCTOS DESTACADOS


conn = mysql.connector.connect(
     host="95.217.155.224",
    user="idesoftbcn",
    password="Idesoftbcn+03.",
    database="gestion_corner_mahou"  
)

cursor = conn.cursor(dictionary=True)

# Consulta SQL para obtener productos destacados
queryprods = """
SELECT 
    productos.id, 
    productos.nombre, 
    productos.descripcion, 
    productos.precio, 
    productos.experto,
    productos.info,
    productos.tiene_alcohol,
    sub_categorias.nombre as subcat_nombre, 
    sub_categorias.descripcion as subcat_descripcion, 
    sub_categorias.es_cerveza,
    categorias.nombre as cat_nombre, 
    categorias.descripcion as cat_descripcion
FROM 
    productos
JOIN 
    sub_categorias ON productos.sub_categoria_id = sub_categorias.id
JOIN 
    categorias ON categorias.id = sub_categorias.categoria_id
WHERE 
    productos.deleted_at IS NULL
    AND (categorias.nombre = 'Destacados' OR sub_categorias.nombre = 'Cervezas destacadas')
"""

# Ejecutar la consulta
cursor.execute(queryprods)

# Obtener los resultados
resultados = cursor.fetchall()

# Cerrar el cursor y la conexión
cursor.close()
conn.close()

# Mostrar los resultados

for producto in resultados:

    print(f"ID: {producto['id']}")
    print(f"Nombre: {producto['nombre']}")
    print(f"Descripción: {producto['descripcion']}")
    print(f"Precio: {producto['precio']}")
    print(f"Experto: {producto['experto']}")
    print(f"Info: {producto['info']}")
    print(f"Tiene Alcohol: {producto['tiene_alcohol']}")
    print(f"Subcategoría Nombre: {producto['subcat_nombre']}")
    print(f"Subcategoría Descripción: {producto['subcat_descripcion']}")
    print(f"Es Cerveza: {producto['es_cerveza']}")
    print(f"Categoría Nombre: {producto['cat_nombre']}")
    print(f"Categoría Descripción: {producto['cat_descripcion']}")
    print("-" * 40)

# %%
recomendados=[]
for n in resultados:
    recomendados.append(n['nombre'])

# %%
recomendados
# %%
