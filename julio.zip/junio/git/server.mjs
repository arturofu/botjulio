import http from 'http';
import open from 'open';
import { spawn } from 'child_process';

import express from 'express';
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
console.log('heeeel')

app.post('/generate-response', (req, res) => {
    const userInput = req.body.userInput;
    const datos = {
      nombre: 'Raquel',
      userinput: userInput,
      contexto: '',
    
    };
    console.log('gggg',datos)
    const pythonProcess = spawn('python', ['botmayo.py', JSON.stringify(datos)]);
    console.log('errror')
    pythonProcess.stdout.on('data', (data) => {
    const response = data.toString();
    res.send(response);
  });

  pythonProcess.stderr.on('data', (data) => {
      console.error(`Error en proceso Python: ${data}`);
      res.status(500).send('¡Ups! Hubo un error al procesar tu solicitud.');

  });
});

app.listen(PORT, () => {
  console.log(`Servidor web iniciado en el puerto ${PORT}`);
});




