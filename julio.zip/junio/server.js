const express = require('express');
const bodyParser = require('body-parser');
const { spawn } = require('child_process');

const app = express();
const port = 3000;

app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

app.post('/process', (req, res) => {

    const userInput = req.body.input;
  
    const datos = {
        nombre: 'Raquel',
        idioma:'ES',
        tiempo:'25 grados',
        userinput: userInput,
        contexto:[{'role':'user','content':userInput}], 
        noticias:'el madrid es campeon de la 15 champions'
      
      };
      console.log('ver_datos',datos)
    const pythonProcess = spawn('python', ['Mahoubotjunio03.py', JSON.stringify(datos)]);

    pythonProcess.stdout.on('data', (data) => {
        const response = data.toString();
        console.log('Respuesta del script de Python:', response);
        //res.json({ response: response });

        const responseObject = JSON.parse(response);
        // Extraer la cadena contxt del objeto responseObject
        const resp= responseObject.respuesta;   
                
        res.json({ response: resp });    
        
        console.log('contxxxt', responseObject);
      
    });

    pythonProcess.stderr.on('data', (data) => {
        console.error('Error:', data.toString());
        res.status(500).json({ error: 'Internal Server Error' });
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
