
#Relación de productos extraídos de la base de datos

tourl = {'mahou clásica': 'https://plazamahou.es/products?productid=36', 'mahou 5 estrellas': 'https://plazamahou.es/products?productid=37', 'mahou 5 estrellas sin gluten': 'https://plazamahou.es/products?productid=38', 'mahou 5 estrellas radler': 'https://plazamahou.es/products?productid=39', 'solan botella 1/2': 'https://plazamahou.es/products?productid=43', 'coca cola zero bot': 'https://plazamahou.es/products?productid=44', 'mahou 5 estrellas session ipa': 'https://plazamahou.es/products?productid=48', 'mahou sin': 'https://plazamahou.es/products?productid=52', 'mahou 0.0 tostada': 'https://plazamahou.es/products?productid=62', 'mahou maestra doble lúpulo': 'https://plazamahou.es/products?productid=63', 'mahou maestra dunkel': 'https://plazamahou.es/products?productid=64', 'mahou barrica original': 'https://plazamahou.es/products?productid=65', 'mahou 5 estrellas sin filtrar': 'https://plazamahou.es/products?productid=66', 'mahou rosé': 'https://plazamahou.es/products?productid=67', 'mahou barrica bourbon': 'https://plazamahou.es/products?productid=68', 'coca cola bot': 'https://plazamahou.es/products?productid=71', 'fanta naranja bot ': 'https://plazamahou.es/products?productid=72', 'fanta limon bot': 'https://plazamahou.es/products?productid=73', 'aquarius naranja bot 30': 'https://plazamahou.es/products?productid=75', 'aquarius limon bot 30': 'https://plazamahou.es/products?productid=77', 'sprite bot ': 'https://plazamahou.es/products?productid=78', 'nestea bot ': 'https://plazamahou.es/products?productid=79', 'tonica bot ': 'https://plazamahou.es/products?productid=80', 'tinto copa': 'https://plazamahou.es/products?productid=81', 'blanco copa': 'https://plazamahou.es/products?productid=82', 'rosado copa': 'https://plazamahou.es/products?productid=83', 'samargo grifo': 'https://plazamahou.es/products?productid=84', 'vermut': 'https://plazamahou.es/products?productid=85', 'gazpacho andaluz': 'https://plazamahou.es/products?productid=87', 'ensaladilla rusa de atún': 'https://plazamahou.es/products?productid=197', 'ensalada de tomates y cebolleta': 'https://plazamahou.es/products?productid=90', 'patatas bravas': 'https://plazamahou.es/products?productid=198', 'torreznos': 'https://plazamahou.es/products?productid=93', 'croquetas de jamón': 'https://plazamahou.es/products?productid=192', 'croquetas de puerro': 'https://plazamahou.es/products?productid=95', 'pimientos del padrón': 'https://plazamahou.es/products?productid=96', 'alcachofas confitadas con bacon': 'https://plazamahou.es/products?productid=97', 'gilda clásica ': 'https://plazamahou.es/products?productid=100', 'pincho de tortilla de patata': 'https://plazamahou.es/products?productid=102', 'tortilla de patata entera': 'https://plazamahou.es/products?productid=103', 'pulguita de jamón': 'https://plazamahou.es/products?productid=104', ' pulguita de pepito de solomillo ': 'https://plazamahou.es/products?productid=106', 'bocata de pepito de solomillo': 'https://plazamahou.es/products?productid=107', 'churros con chocolate': 'https://plazamahou.es/products?productid=195', 'tarta de queso': 'https://plazamahou.es/products?productid=110', 'torrija de pan brioche': 'https://plazamahou.es/products?productid=111', 'helados variados': 'https://plazamahou.es/products?productid=113', 'solan gas botella 1/3': 'https://plazamahou.es/products?productid=115', 'mahou clásica doble': 'https://plazamahou.es/products?productid=116', 'ron': 'https://plazamahou.es/products?productid=118', 'vodka': 'https://plazamahou.es/products?productid=119', 'mahou clásica tercio': 'https://plazamahou.es/products?productid=120', 'huevos rotos con jamón ': 'https://plazamahou.es/products?productid=121', 'calamares a la andaluza': 'https://plazamahou.es/products?productid=194', 'whisky': 'https://plazamahou.es/products?productid=124', 'ginebra': 'https://plazamahou.es/products?productid=125', 'bocata de jamón': 'https://plazamahou.es/products?productid=126', 'pulguita de calamares': 'https://plazamahou.es/products?productid=201', 'bocata de calamares': 'https://plazamahou.es/products?productid=193', 'pulguita de sandwich mixto': 'https://plazamahou.es/products?productid=130', 'bocata de sandwich mixto': 'https://plazamahou.es/products?productid=132', 'pulguita de lomo con queso y pimientos': 'https://plazamahou.es/products?productid=133', 'bocata de lomo con queso y pimientos': 'https://plazamahou.es/products?productid=134', 'cazuelita de gambas al ajillo': 'https://plazamahou.es/products?productid=135', 'dados de merluza a la romana': 'https://plazamahou.es/products?productid=136', 'alitas de pollo a la madrileña': 'https://plazamahou.es/products?productid=137', 'albóndigas con patatas paja': 'https://plazamahou.es/products?productid=138', 'rabo de toro con parmentier': 'https://plazamahou.es/products?productid=139', 'boquerones en vinagre': 'https://plazamahou.es/products?productid=141', 'mejillones en escabeche con patatas': 'https://plazamahou.es/products?productid=142', 'jamón ibérico de bellota (media)': 'https://plazamahou.es/products?productid=143', 'jamón ibérico de bellota ': 'https://plazamahou.es/products?productid=144', 'tabla de chacinas (media)': 'https://plazamahou.es/products?productid=145', 'tabla de chacinas': 'https://plazamahou.es/products?productid=146', 'tabla de quesos (media)': 'https://plazamahou.es/products?productid=147', 'tabla de quesos ': 'https://plazamahou.es/products?productid=148', 'tabla mixta (media)': 'https://plazamahou.es/products?productid=149', 'tabla mixta': 'https://plazamahou.es/products?productid=150', 'aperitivo 5 estrellas': 'https://plazamahou.es/products?productid=151', 'entrecote de la sierra de guadarrama con patatas fritas': 'https://plazamahou.es/products?productid=191', 'mahou clásica caña': 'https://plazamahou.es/products?productid=156', 'mahou 5 estrellas doble': 'https://plazamahou.es/products?productid=157', 'mahou 5 estrellas tercio': 'https://plazamahou.es/products?productid=158', 'mahou 5 estrellas caña': 'https://plazamahou.es/products?productid=160', 'mahou 0.0 tostada caña': 'https://plazamahou.es/products?productid=162', 'mahou 0.0 tostada doble': 'https://plazamahou.es/products?productid=163', 'mahou 0.0 tostada tercio': 'https://plazamahou.es/products?productid=164', 'mahou 5 estrellas radler caña': 'https://plazamahou.es/products?productid=165', 'mahou 5 estrellas radler tercio': 'https://plazamahou.es/products?productid=166', 'mahou 5 estrellas session ipa caña': 'https://plazamahou.es/products?productid=167', 'mahou 5 estrellas session ipa doble': 'https://plazamahou.es/products?productid=168', 'mahou 5 estrellas session ipa tercio': 'https://plazamahou.es/products?productid=169', 'mahou 5 estrellas sin filtrar caña': 'https://plazamahou.es/products?productid=170', 'mahou 5 estrellas sin filtrar doble': 'https://plazamahou.es/products?productid=171', 'mahou 5 estrellas sin filtrar tercio': 'https://plazamahou.es/products?productid=172', 'mahou 5 estrellas sin gluten tercio': 'https://plazamahou.es/products?productid=175', 'mahou barrica bourbon tercio': 'https://plazamahou.es/products?productid=176', 'mahou barrica original tercio': 'https://plazamahou.es/products?productid=177', 'mahou bodega': 'https://plazamahou.es/products?productid=178', 'mahou bodega caña': 'https://plazamahou.es/products?productid=179', 'mahou maestra doble lúpulo caña': 'https://plazamahou.es/products?productid=181', 'mahou maestra doble lúpulo doble': 'https://plazamahou.es/products?productid=182', 'mahou maestra dunkel tercio': 'https://plazamahou.es/products?productid=183', 'mahou maestra doble lúpulo tercio': 'https://plazamahou.es/products?productid=184', 'mahou rosé tercio': 'https://plazamahou.es/products?productid=185', 'mahou sin tercio': 'https://plazamahou.es/products?productid=186', 'mahou 5 estrellas radler doble': 'https://plazamahou.es/products?productid=189', 'mahou bodega doble': 'https://plazamahou.es/products?productid=190', 'tosta de anchoa y mantequilla (2uds)': 'https://plazamahou.es/products?productid=202', 'gilda con boquerón': 'https://plazamahou.es/products?productid=205', 'huevos rotos con pisto': 'https://plazamahou.es/products?productid=206', 'mahou destacada': 'https://plazamahou.es/products?productid=208', 'cervezas': 'https://plazamahou.es/products?cat=4&subcat=1', 'bebidas': 'https://plazamahou.es/products?cat=3', 'comidas': 'https://plazamahou.es/products?cat=4', 'destacados': 'https://plazamahou.es/products?cat=8', 'aguas': 'https://plazamahou.es/products?cat=4&subcat=10', 'refrescos': 'https://plazamahou.es/products?cat=4&subcat=11', 'vino': 'https://plazamahou.es/products?cat=4&subcat=12', 'alcohólicas': 'https://plazamahou.es/products?cat=4&subcat=13', 'raciones': 'https://plazamahou.es/products?cat=4&subcat=9', 'aperitivos': 'https://plazamahou.es/products?cat=4&subcat=15', 'entrepanes': 'https://plazamahou.es/products?cat=4&subcat=16', 'postres': 'https://plazamahou.es/products?cat=4&subcat=17', 'cervezas destacadas': 'https://plazamahou.es/products?cat=4&subcat=18'}
infocarto=[{'categoria': 'Aperitivos', 'productos': ['Gilda clásica ', 'Boquerones en vinagre', 'Mejillones en escabeche con patatas', 'Jamón ibérico de bellota (media)', 'Jamón ibérico de bellota ', 'Tabla de chacinas (media)', 'Tabla de chacinas', 'Tabla de quesos (media)', 'Tabla de quesos ', 'Tabla mixta (media)', 'Tabla mixta', 'Aperitivo 5 estrellas', 'Tosta de anchoa y mantequilla (2uds)', 'Gilda con boquerón']}, {'categoria': 'Cervezas destacadas', 'productos': ['Pulguita de calamares', 'Entrecote de la sierra de guadarrama con patatas fritas', 'Croquetas de jamón', 'Bocata de calamares', 'Calamares a la andaluza', 'Churros con chocolate', 'Ensaladilla rusa de atún', 'Patatas Bravas', 'Mahou Destacada']}, {'categoria': 'Entrepanes', 'productos': ['Pulguita de Jamón', ' Pulguita de PEPITO DE SOLOMILLO ', 'Bocata de pepito de solomillo', 'Bocata de Jamón', 'Bocata de calamares', 'Pulguita de Sandwich mixto', 'Bocata de sandwich mixto', 'Pulguita de lomo con queso y pimientos', 'Bocata de lomo con queso y pimientos', 'Pulguita de calamares']}, {'categoria': 'Postres', 'productos': ['Churros con chocolate', 'Tarta de queso', 'Torrija de pan brioche', 'Helados variados']}, {'categoria': 'aguas', 'productos': ['SOLAN BOTELLA 1/2', 'SOLAN GAS BOTELLA 1/3']}, {'categoria': 'alcohólicas', 'productos': ['VERMUT', 'ron', 'vodka', 'Whisky', 'ginebra']}, {'categoria': 'cervezas', 'productos': ['Mahou Clásica', 'Mahou 5 Estrellas', 'Mahou 5 Estrellas Sin Gluten', 'Mahou 5 Estrellas Radler', 'MAHOU 5 ESTRELLAS SESSION IPA', 'MAHOU SIN', 'MAHOU 0.0 TOSTADA', 'MAHOU MAESTRA DOBLE LÚPULO', 'MAHOU MAESTRA DUNKEL', 'MAHOU BARRICA ORIGINAL', 'MAHOU 5 ESTRELLAS SIN FILTRAR', 'MAHOU ROSÉ', 'MAHOU BARRICA BOURBON', 'Mahou Clásica Doble', 'Mahou Clásica Tercio', 'Mahou Clásica Caña', 'Mahou 5 Estrellas Doble', 'Mahou 5 Estrellas Tercio', 'Mahou 5 Estrellas Caña', 'MAHOU 0.0 TOSTADA Caña', 'MAHOU 0.0 TOSTADA Doble', 'MAHOU 0.0 TOSTADA Tercio', 'Mahou 5 Estrellas Radler Caña', 'Mahou 5 Estrellas Radler Tercio', 'MAHOU 5 ESTRELLAS SESSION IPA Caña', 'MAHOU 5 ESTRELLAS SESSION IPA Doble', 'MAHOU 5 ESTRELLAS SESSION IPA Tercio', 'MAHOU 5 ESTRELLAS SIN FILTRAR Caña', 'MAHOU 5 ESTRELLAS SIN FILTRAR Doble', 'MAHOU 5 ESTRELLAS SIN FILTRAR Tercio', 'Mahou 5 Estrellas Sin Gluten Tercio', 'MAHOU BARRICA BOURBON Tercio', 'MAHOU BARRICA ORIGINAL Tercio', 'Mahou Bodega', 'Mahou Bodega Caña', 'MAHOU MAESTRA DOBLE LÚPULO Caña', 'MAHOU MAESTRA DOBLE LÚPULO Doble', 'MAHOU MAESTRA DUNKEL Tercio', 'MAHOU MAESTRA DOBLE LÚPULO Tercio', 'MAHOU ROSÉ Tercio', 'MAHOU SIN Tercio', 'Mahou 5 Estrellas Radler Doble', 'Mahou Bodega Doble']}, {'categoria': 'raciones', 'productos': ['Gazpacho Andaluz', 'Ensaladilla rusa de atún', 'Ensalada de tomates y cebolleta', 'Patatas Bravas', 'Torreznos', 'Croquetas de jamón', 'Croquetas de puerro', 'Pimientos del padrón', 'Alcachofas confitadas con bacon', 'Pincho de Tortilla de patata', 'Tortilla de patata entera', 'Huevos rotos con jamón ', 'Calamares a la andaluza', 'Cazuelita de gambas al ajillo', 'Dados de merluza a la romana', 'Alitas de pollo a la madrileña', 'Albóndigas con patatas paja', 'Rabo de toro con parmentier', 'Entrecote de la sierra de guadarrama con patatas fritas', 'Huevos rotos con pisto']}, {'categoria': 'refrescos', 'productos': ['COCA COLA ZERO bot', 'COCA COLA BOT', 'FANTA NARANJA BOT ', 'FANTA LIMON BOT', 'AQUARIUS NARANJA BOT 30', 'AQUARIUS LIMON BOT 30', 'SPRITE BOT ', 'NESTEA BOT ', 'TONICA BOT ']}, {'categoria': 'vino', 'productos': ['TINTO COPA', 'BLANCO COPA', 'ROSADO COPA', 'SAMARGO GRIFO']}]
raciones={'productos': ['Gazpacho Andaluz', 'Ensaladilla rusa de atún', 'Ensalada de tomates y cebolleta', 'Patatas Bravas', 'Torreznos', 'Croquetas de jamón', 'Croquetas de puerro', 'Pimientos del padrón', 'Alcachofas confitadas con bacon', 'Pincho de Tortilla de patata', 'Tortilla de patata entera', 'Huevos rotos con jamón ', 'Calamares a la andaluza', 'Cazuelita de gambas al ajillo', 'Dados de merluza a la romana', 'Alitas de pollo a la madrileña', 'Albóndigas con patatas paja', 'Rabo de toro con parmentier', 'Entrecote de la sierra de guadarrama con patatas fritas', 'Huevos rotos con pisto']}
aguas={'productos': ['SOLAN BOTELLA 1/2', 'SOLAN GAS BOTELLA 1/3']}
refrescos={'productos': ['COCA COLA ZERO bot', 'COCA COLA BOT', 'FANTA NARANJA BOT ', 'FANTA LIMON BOT', 'AQUARIUS NARANJA BOT 30', 'AQUARIUS LIMON BOT 30', 'SPRITE BOT ', 'NESTEA BOT ', 'TONICA BOT ']}
vino={'productos': None}
alcoholicas={'productos': None}
raciones={'productos': ['Gazpacho Andaluz', 'Ensaladilla rusa de atún', 'Ensalada de tomates y cebolleta', 'Patatas Bravas', 'Torreznos', 'Croquetas de jamón', 'Croquetas de puerro', 'Pimientos del padrón', 'Alcachofas confitadas con bacon', 'Pincho de Tortilla de patata', 'Tortilla de patata entera', 'Huevos rotos con jamón ', 'Calamares a la andaluza', 'Cazuelita de gambas al ajillo', 'Dados de merluza a la romana', 'Alitas de pollo a la madrileña', 'Albóndigas con patatas paja', 'Rabo de toro con parmentier', 'Entrecote de la sierra de guadarrama con patatas fritas', 'Huevos rotos con pisto']}
aperitivos={'productos': None}
entrepanes={'productos': None}
postres={'productos': None}
cervezas=[
    {
        "nombre": "MAHOU 0.0 TOSTADA",
        "amargor": "24",
        "descripcion": "\r\n\r\nSabores de malta tostada, con ligeros toques herbales de lúpulo. En boca es ligera de cuerpo, de amargor suave y leve regusto dulce.",
        "precio": "2.00 €",
        "alcohol": "0,0 grados",
        "curiosidad": "UN SABOR QUE DESMONTA PREJUICIOS.<br/><br/>Mahou 0.0 Tostada es laborada con los mismos ingredientes que cualquier otra cerveza con alcohol. Se ajustan y controlan ciertos parámetros como temperaturas y tiempos durante el proceso de elaboración del mosto, para conseguir un mosto cervecero con menos azúcares fermentables. Esto, junto con el control de las temperaturas de fermentación, hace que la producción de alcohol sea limitada."
    },
    {
        "nombre": "Mahou 5 Estrellas",
        "amargor": "27",
        "descripcion": "B3\r\n\r\nEquilibrio de sabores de fermentación, lúpulo y malta. Con cuerpo y amargor moderado.",
        "precio": "1.50 €",
        "alcohol": "5,5 grados",
        "curiosidad": "EL CORAZÓN DE LA FAMILIA.<br/><br/> Coincidiendo con la inaguración de la fábrica del Paseo Imperial en 1962, los barriles de madera se sustituyeron por los de metal que eran mucho más duraderos y óptimos para la conservación de la cerveza"
    },
    {
        "nombre": "Mahou 5 Estrellas Radler",
        "amargor": "11",
        "descripcion": "Sabor fresco fruto de la combinación de su aroma a limón con toques florales,amargor suave y moderada acidez.",
        "precio": "2.00 €",
        "alcohol": "3,25 grados",
        "curiosidad": "EL SABOR QUE NOS UNE.<br/><br/> La popularidad de este tipo de cerveza se remonta a la década de 1920 en Baviera, como bebida refrescante después de la práctica del ciclismo (Radler significa ciclista en Alemán), muy de moda en esa época, aunque los orígenes se creen que son anteriores."
    },
    {
        "nombre": "MAHOU 5 ESTRELLAS SESSION IPA",
        "amargor": "40",
        "descripcion": "Explosión de sabor del lúpulo (recuerdos a melocotón, grosella, cítricos, balsámicos), junto con un amargor y cuerpo moderado. ",
        "precio": "2.00 €",
        "alcohol": "4,5 grados",
        "curiosidad": "SI CREES EN ALGO, CRÉALO.<br/><br/>En Mahou 5 Estrellas Session IPA se incorporan lúpulos americanos en diferentes momentos del proceso de elaboración. Al principio de la ebullición se dosifican lúpulos para proporcionar amargor. La dosificación de variedades aromáticas al final de la ebullición permite la extracción de aceites aromáticos que permanecen en la cerveza y aportan los aromas afrutados, cítricos, resinosos y florales. Esta técnica se conoce como late hopping. Finalmente, la dosificación de nuevo al final de la fermentación de lúpulos aromáticos aporta nuevos aromas e intensifica el carácter lupulado de una forma muy especial. Esta técnica se conoce como dry hopping."
    },
    {
        "nombre": "MAHOU 5 ESTRELLAS SIN FILTRAR",
        "amargor": "24,5",
        "descripcion": "Destacan los sabores de malta, lúpulo y fermentación, con un velado justo y una textura sedosa.",
        "precio": "2.00 €",
        "alcohol": "5,5 grados",
        "curiosidad": "ALMA CERVECERA.<br/><br/>A diferencia de otras cervezas, esta no pasa por un proceso de filtración. En el proceso, una vez terminada la fermentación la cerveza pasa a un proceso de guarda donde maduran los sabores y terminan de aﬁnarse, lo que permite destacar los sabores de malta, lúpulo y fermentación y disfrutarlos en una nueva experiencia Cinco Estrellas con un velado justo y una textura sedosa."
    },
    {
        "nombre": "Mahou 5 Estrellas Sin Gluten",
        "amargor": "27",
        "descripcion": "Equilibrio de sabores de fermentación, lúpulo y malta. Con cuerpo y amargor moderado.",
        "precio": "2.00 €",
        "alcohol": "5,5 grados",
        "curiosidad": "EL SABOR QUE NOS UNE.<br/><br/> Elaborada de la misma forma y con los mismos ingredientes que Mahou 5 Estrellas, pero sometida a un proceso en el que se degradan las proteínas que forman el gluten. El resultado es una cerveza Sin Gluten con el mismo sabor que Mahou 5 Estrellas"
    },
    {
        "nombre": "MAHOU BARRICA BOURBON",
        "amargor": "23",
        "descripcion": "Predominan los aromas a coco y vainilla, las notas de maltas tostadas y las sensaciones a frutas maduras. Amargo y cuerpo moderados con un punto de dulzor y una ligera fragancia alcohólica.",
        "precio": "2.00 €",
        "alcohol": "6,9 grados",
        "curiosidad": "REVIENTA LAS REGLAS.<br/><br/>Mahou Barrica Bourbon es envejecida varios meses en barricas usadas previamente para envejecer bourbon. El bourbon debe ser madurado en barricas de roble americano en EEUU. Esto proporciona una mezcla de aromas provenientes de la madera además de los que aporta los restos de bourbon que quedan impregnados en las paredes."
    },
    {
        "nombre": "MAHOU BARRICA ORIGINAL",
        "amargor": "25",
        "descripcion": "Sabor de las maltas tostadas, junto con notas de madera, coco y vainilla. Amargo moderado, con cuerpo y regusto dulce.",
        "precio": "2.00 €",
        "alcohol": "6,1 grados",
        "curiosidad": "REVIENTA LAS REGLAS.<br/><br/>Mahou Barrica Original es envejecida varios meses en barricas nuevas de roble americano. El roble americano le va a aportar los matices a vainilla y coco. El tostado de la madera le aporta aromas ahumados y tostados. Asimismo, el proceso de envejecimiento hace evolucionar los aromas de la cerveza, apareciendo aromas mas complejos a fruta madura o frutos secos."
    },
    {
        "nombre": "Mahou Bodega",
        "amargor": "25",
        "descripcion": "Bodega",
        "precio": "2.00 €",
        "alcohol": "6,1 grados",
        "curiosidad": "REVIENTA LAS REGLAS.<br/><br/>Mahou Barrica Original es envejecida varios meses en barricas nuevas de roble americano. El roble americano le va a aportar los matices a vainilla y coco. El tostado de la madera le aporta aromas ahumados y tostados. Asimismo, el proceso de envejecimiento hace evolucionar los aromas de la cerveza, apareciendo aromas mas complejos a fruta madura o frutos secos."
    },
    {
        "nombre": "Mahou Clásica",
        "amargor": "24",
        "descripcion": "De aroma ligero y equilibrado, cuerpo moderado y amargor suave. ",
        "precio": "2.00 €",
        "alcohol": "4,8 grados",
        "curiosidad": "Es la referencia más vinculada a nuestra historia e icono de la 'caña' perfecta. El botellín de 20cl se convirtió en un formato clásico y exitoso bautizado como 'botijo'. Hoy el botijo es un objeto de culto. deseado y subastado en internet como una pequeña pieza de historia y arte."
    },
    {
        "nombre": "MAHOU MAESTRA DUNKEL",
        "amargor": "25",
        "descripcion": "Toda una gama de sabores tostados desde el café, chocolate, ahumado pasando por  las frutas pasas y tabaco. Con cuerpo y amargor moderado",
        "precio": "2.00 €",
        "alcohol": "6,1 grados",
        "curiosidad": "DE MAESTROS CERVECEROS PARA MAESTROS CERVECEROS.<br/><br/>La etapa de maceración, durante la elaboración del mosto, se realiza de la forma tradicional en que se elaboraba antiguamente, mediante un proceso de triple temple o decocción, mucho más largo de lo habitual, y que consiste en llevar a ebullición una parte del volumen de la maceración (con más proporción de grano), para luego volcarla de nuevo en la maceración principal y, así subir la temperatura rápidamente y de forma controlada. Este método incrementa el color e intensifica el carácter de la malta, expresándose mas los aromas tostados, a chocolate, a tabaco o pasas."
    },
    {
        "nombre": "MAHOU ROSÉ",
        "amargor": "10",
        "descripcion": "Carácter refrescante marcado por el equilibrio de sus notas afrutadas, amargor y cuerpo.",
        "precio": "2.00 €",
        "alcohol": "4,8 grados",
        "curiosidad": "EL SABOR DE ALGO INESPERADO.<br/><br/>Mahou rosé se postula como una alternativa perfecta para el público más joven, que está dispuesto a descubrir y experimentar nuevas experiencias. Incluso para los No cerveceros que quieren tener una opción en el momento de consumo de la cerveza."
    },
    {
        "nombre": "MAHOU SIN",
        "amargor": "18,5",
        "descripcion": "Destacan los aromas de cereal, con ligeras notas herbales de lúpulo. De amargor amargor suave, cuerpo ligero y leve regusto dulce.",
        "precio": "2.00 €",
        "alcohol": "0,8 grados",
        "curiosidad": "LA SIN DE MAHOU, CON TODO EL SABOR DE LA CERVEZA DE SIEMPRE.<br/><br/>Mahou tuvo una vinculación especial con el Real Madrid porque el maestro cervecero fue jugador del segundo equipo. Y Alfredo Mahou de la Fuente (bisnieto de Casimiro) formó parte del conjunto blanco de baloncesto. «Desde un comienzo Mahou apoyó a los dos equipos de fútbol de la ciudad, no eran los patrocinios de ahora pero les ayudaba de otra forma. Enviaban, por ejemplo, marcadores», explican desde la compañía. «En la familia había paridad de seguidores de un equipo y otro y la familia era bastante deportista."
    }
]
recomendados=['Pulguita de calamares', 'Entrecote de la sierra de guadarrama con patatas fritas', 'Croquetas de jamón', 'Bocata de calamares', 'Calamares a la andaluza', 'Churros con chocolate', 'Ensaladilla rusa de atún', 'Patatas Bravas', 'Mahou Destacada']
